#Made by Jason Cariaga
#purpose is to have a thruster deactivate after hovering for some time.
#this file is merely a test run to ensure which thruster(s) are off or on based on the situation wanted

import logging
import time
from threading import Thread

import cflib.crtp
from cflib.crazyflie import Crazyflie
from cflib.crazyflie.log import LogConfig

URI = 'radio://0/80/250K'

logging.basicConfig(level=logging.ERROR)

file = '1'


class MotorRampExample:
    """Example that connects to a Crazyflie and ramps the motors up/down and
    the disconnects"""

    def __init__(self, link_uri):
        """ Initialize and run the example with the specified link_uri """

        self._cf = Crazyflie(rw_cache='./cache')

        self._cf.connected.add_callback(self._connected)
        self._cf.disconnected.add_callback(self._disconnected)
        self._cf.connection_failed.add_callback(self._connection_failed)
        self._cf.connection_lost.add_callback(self._connection_lost)

        self._cf.open_link(link_uri)

        print('Connecting to %s' % link_uri)

    def _connected(self, link_uri):
        """ This callback is called form the Crazyflie API when a Crazyflie
        has been connected and the TOCs have been downloaded."""

        # Start a separate thread to do the motor test.
        # Do not hijack the calling thread!
        Thread(target=self._ramp_motors).start()

        #code in the bottom is added for configuring stabilizer (WORKS FINE)
        self._lg_mag = LogConfig(name='Magnetometer', period_in_ms=10)
        self._lg_mag.add_variable('mag.x', 'float')
        self._lg_mag.add_variable('mag.y', 'float')
        self._lg_mag.add_variable('mag.z', 'float')

        #code here should be for the accelerometer: (WORKS)
        self._lg_acc = LogConfig(name='Accelerometer', period_in_ms=10)
        self._lg_acc.add_variable('acc.x', 'float')
        self._lg_acc.add_variable('acc.y', 'float')
        self._lg_acc.add_variable('acc.z', 'float')

        # code here should be for the accelerometer: (WORKS)
        self._lg_gyro = LogConfig(name='Gyroscope', period_in_ms=10)
        self._lg_gyro.add_variable('gyro.x', 'float')
        self._lg_gyro.add_variable('gyro.y', 'float')
        self._lg_gyro.add_variable('gyro.z', 'float')

        # Adding the configuration cannot be done until a Crazyflie is
        # connected, since we need to check that the variables we
        # would like to log are in the TOC.
        try:
            self._cf.log.add_config(self._lg_mag)
            self._cf.log.add_config(self._lg_acc)
            self._cf.log.add_config(self._lg_gyro)
            # This callback will receive the data
            self._lg_mag.data_received_cb.add_callback(self._stab_log_data)
            self._lg_acc.data_received_cb.add_callback(self._stab_log_data)
            self._lg_gyro.data_received_cb.add_callback(self._stab_log_data)
            # This callback will be called on errors
            self._lg_mag.error_cb.add_callback(self._stab_log_error)
            self._lg_acc.error_cb.add_callback(self._stab_log_error)
            self._lg_gyro.error_cb.add_callback(self._stab_log_error)
            # Start the logging
            self._lg_mag.start()
            self._lg_acc.start()
            self._lg_gyro.start()

        except KeyError as e:
            print('Could not start log configuration,'
                  '{} not found in TOC'.format(str(e)))
        except AttributeError:
            print('Could not add Stabilizer log config, bad configuration.')

    def _stab_log_error(self, logconf, msg):
        """Callback from the log API when an error occurs"""
        print('Error when logging %s: %s' % (logconf.name, msg))

    def _stab_log_data(self, timestamp, data, logconf):
        """Callback from the log API when data arrives"""
        print('[%d][%s]: %s' % (timestamp, logconf.name, data))


    def _connection_failed(self, link_uri, msg):
        """Callback when connection initial connection fails (i.e no Crazyflie
        at the specified address)"""
        print('Connection to %s failed: %s' % (link_uri, msg))

    def _connection_lost(self, link_uri, msg):
        """Callback when disconnected after a connection has been made (i.e
        Crazyflie moves out of range)"""
        print('Connection to %s lost: %s' % (link_uri, msg))

    def _disconnected(self, link_uri):
        """Callback when the Crazyflie is disconnected (called in all cases)"""
        print('Disconnected from %s' % link_uri)

    def _ramp_motors(self):

        # Unlock startup thrust protection
        self._cf.commander.send_setpoint(0, 0, 0, 0)

        pitch = 63000
        roll = 60000

        for y in range(30):
            self._cf.commander.send_hover_setpoint(0,0,0,y/30)
            time.sleep(.1)

        #issue is combining send_setpoint with setvalue for motorPowerSet
        for y in range(100):
            self._cf.commander.send_hover_setpoint(0, 0, 0, 1)
            if y >= 50:
                self._cf.param.set_value('motorPowerSet.m2', str(0))
                self._cf.param.set_value('motorPowerSet.m3', str(0))
                #self._cf.commander.send_setpoint(0, 0, 0, 1)
            #else:
            #    self._cf.commander.send_hover_setpoint(0, 0, 0, 1)
            time.sleep(.1)

        #for y in range(20):
        #    """the code to drop the crazyflie"""
        #    """allows drone to crash using thruster modification"""
        #    self._cf.commander.send_setpoint(0, 0, 0, 0)

#        for y in range(50):
            #if y < 30:
            #enable setvalue isnt really needed
#            self._cf.param.set_value('motorPowerSet.enable', str(1))
#            self._cf.param.set_value('motorPowerSet.m2', str(9000))
#            self._cf.param.set_value('motorPowerSet.m4', str(9000))
#            time.sleep(.1)

        self._cf.param.set_value('motorPowerSet.m1', str(0))
        self._cf.param.set_value('motorPowerSet.m2', str(0))
        self._cf.param.set_value('motorPowerSet.m3', str(0))
        self._cf.param.set_value('motorPowerSet.m4', str(0))

#        for y in range(20):
#            self._cf.commander.send_hover_setpoint(0,0,0,1)
#            time.sleep(.1)

#        for y in range(50):
#            self._cf.param.set_value('motorPowerSet.m2', str(0))
#            self._cf.param.set_value('motorPowerSet.m3', str(0))
#            self._cf.param.set_value('motorPowerSet.m4', str(0))
#            time.sleep(.1)

        self._cf.commander.send_setpoint(0, 0, 0, 0)
        # Make sure that the last packet leaves before the link is closed
        # since the message queue is not flushed before closing
        time.sleep(0.1)
        self._cf.close_link()


if __name__ == '__main__':
    # Initialize the low-level drivers (don't list the debug drivers)
    cflib.crtp.init_drivers(enable_debug_driver=False)
    # Scan for Crazyflies and use the first one found
    print('Scanning interfaces for Crazyflies...')
    available = cflib.crtp.scan_interfaces()
    print('Crazyflies found:')
    for i in available:
        print(i[0])

    if len(available) > 0:
        le = MotorRampExample(available[0][0])
    else:
        print('No Crazyflies found, cannot run example')