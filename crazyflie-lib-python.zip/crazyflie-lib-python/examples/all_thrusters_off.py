#Made by Jason Cariaga
#purpose is to have a thruster deactivate after hovering for some time.
#also provides a descent in thruster speed as falldown occurs in order to preserve damage post-crash
#should work exactly like one_thruster.py EXCEPT the output should contain sensor information.
#mainly: accelerometer, magnetometer, and gyroscope information

import csv
import logging
import time
from threading import Thread
from threading import Timer

import cflib.crtp
from cflib.crazyflie import Crazyflie
from cflib.crazyflie.log import LogConfig

URI = 'radio://0/80/250K'

logging.basicConfig(level=logging.ERROR)

file = '30'


class MotorRampExample:
    """Example that connects to a Crazyflie and ramps the motors up/down and
    the disconnects"""

    def __init__(self, link_uri):
        """ Initialize and run the example with the specified link_uri """

        self._cf = Crazyflie(rw_cache='./cache')

        self._cf.connected.add_callback(self._connected)
        self._cf.disconnected.add_callback(self._disconnected)
        self._cf.connection_failed.add_callback(self._connection_failed)
        self._cf.connection_lost.add_callback(self._connection_lost)

        self._cf.open_link(link_uri)

        print('Connecting to %s' % link_uri)

    def _connected(self, link_uri):
        """ This callback is called form the Crazyflie API when a Crazyflie
        has been connected and the TOCs have been downloaded."""

        # Start a separate thread to do the motor test.
        # Do not hijack the calling thread!
        Thread(target=self._ramp_motors).start()

        #code in the bottom is added for configuring stabilizer (WORKS FINE)
        self._lg_mag = LogConfig(name='Magnetometer', period_in_ms=10)
        self._lg_mag.add_variable('mag.x', 'float')
        self._lg_mag.add_variable('mag.y', 'float')
        self._lg_mag.add_variable('mag.z', 'float')

        #code here should be for the accelerometer: (WORKS)
        self._lg_acc = LogConfig(name='Accelerometer', period_in_ms=10)
        self._lg_acc.add_variable('acc.x', 'float')
        self._lg_acc.add_variable('acc.y', 'float')
        self._lg_acc.add_variable('acc.z', 'float')

        # code here should be for the accelerometer: (WORKS)
        self._lg_gyro = LogConfig(name='Gyroscope', period_in_ms=10)
        self._lg_gyro.add_variable('gyro.x', 'float')
        self._lg_gyro.add_variable('gyro.y', 'float')
        self._lg_gyro.add_variable('gyro.z', 'float')

        # Adding the configuration cannot be done until a Crazyflie is
        # connected, since we need to check that the variables we
        # would like to log are in the TOC.
        try:
            self._cf.log.add_config(self._lg_mag)
            self._cf.log.add_config(self._lg_acc)
            self._cf.log.add_config(self._lg_gyro)
            # This callback will receive the data
            self._lg_mag.data_received_cb.add_callback(self._stab_log_data)
            self._lg_acc.data_received_cb.add_callback(self._stab_log_data)
            self._lg_gyro.data_received_cb.add_callback(self._stab_log_data)
            # This callback will be called on errors
            self._lg_mag.error_cb.add_callback(self._stab_log_error)
            self._lg_acc.error_cb.add_callback(self._stab_log_error)
            self._lg_gyro.error_cb.add_callback(self._stab_log_error)
            # Start the logging
            self._lg_mag.start()
            self._lg_acc.start()
            self._lg_gyro.start()

        except KeyError as e:
            print('Could not start log configuration,'
                  '{} not found in TOC'.format(str(e)))
        except AttributeError:
            print('Could not add Stabilizer log config, bad configuration.')

        # Start a timer to disconnect in 14 seconds, enough for the crazyflie to record as it induces crash
        #t = Timer(14, self._cf.close_link()) #, self._lg_acc.stop(), self._lg_mag.stop()""")
        #t.start()

    def _stab_log_error(self, logconf, msg):
        """Callback from the log API when an error occurs"""
        print('Error when logging %s: %s' % (logconf.name, msg))

    def _stab_log_data(self, timestamp, data, logconf):
        """Callback from the log API when data arrives"""
        print('[%d][%s]: %s' % (timestamp, logconf.name, data))

        data['timestamp'] = timestamp

        if logconf.name == 'Accelerometer':
            field = ['timestamp','acc.x', 'acc.y', 'acc.z']
        elif logconf.name == 'Gyroscope':
            field = ['timestamp','gyro.x', 'gyro.y', 'gyro.z']
        else:
            field = ['timestamp','mag.x', 'mag.y', 'mag.z']

        # name of csv file
        filename = "D:/ResearchData/" + logconf.name + file + ".csv"

        # writing to csv file
        with open(filename, 'a') as csvfile:
            # creating a csv dict writer object
            writer = csv.DictWriter(csvfile, fieldnames=field)
            # writing data rows
            writer.writerow(data)


    def _connection_failed(self, link_uri, msg):
        """Callback when connection initial connection fails (i.e no Crazyflie
        at the specified address)"""
        print('Connection to %s failed: %s' % (link_uri, msg))

    def _connection_lost(self, link_uri, msg):
        """Callback when disconnected after a connection has been made (i.e
        Crazyflie moves out of range)"""
        print('Connection to %s lost: %s' % (link_uri, msg))

    def _disconnected(self, link_uri):
        """Callback when the Crazyflie is disconnected (called in all cases)"""
        print('Disconnected from %s' % link_uri)

    def _ramp_motors(self):
        thrust_mult = 1
        thrust_step = 500
        thrust = 20000
        pitch = 0
        roll = 0
        yawrate = 0

        # Unlock startup thrust protection
        self._cf.commander.send_setpoint(0, 0, 0, 0)

        for y in range(20):
            self._cf.commander.send_hover_setpoint(0, 0, 0, y / 20)
            time.sleep(0.1)

        for y in range(80):
            self._cf.commander.send_hover_setpoint(0, 0, 0, 1)
            time.sleep(0.1)

        #as while loop ends,
        # my created code is a for loop to create the one thruster

        self._cf.commander.send_stop_setpoint()
        self._cf.commander.send_setpoint(0, 0, 0, 0)
        # Make sure that the last packet leaves before the link is closed
        # since the message queue is not flushed before closing
        time.sleep(3.0)
        self._cf.close_link()


if __name__ == '__main__':
    # Initialize the low-level drivers (don't list the debug drivers)
    cflib.crtp.init_drivers(enable_debug_driver=False)
    # Scan for Crazyflies and use the first one found
    print('Scanning interfaces for Crazyflies...')
    available = cflib.crtp.scan_interfaces()
    print('Crazyflies found:')
    for i in available:
        print(i[0])

    if len(available) > 0:
        with open('D:/ResearchData/Accelerometer' + file + '.csv', 'w') as csvfile:
            fieldnames = ['timestamp', 'acc.x', 'acc.y', 'acc.z']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
        with open('D:/ResearchData/Gyroscope' + file + '.csv', 'w') as csvfile:
            fieldnames = ['timestamp', 'gyro.x', 'gyro.y', 'gyro.z']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
        with open('D:/ResearchData/Magnetometer' + file + '.csv', 'w') as csvfile:
            fieldnames = ['timestamp', 'mag.x', 'mag.y', 'mag.z']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()

        le = MotorRampExample(available[0][0])
    else:
        print('No Crazyflies found, cannot run example')